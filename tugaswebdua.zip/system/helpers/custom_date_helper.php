<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
 *
 * Custom Display Date
 *
 */	
if ( ! function_exists('display_date'))
{
	function display_date($StringDate = '2000-01-01') {
		$posted = "";

		$WeekDay=date("l", mktime(0, 0, 0, substr($StringDate,5,2), substr($StringDate,8,2), substr($StringDate,0,4)));
		$dDay = array(
		"Monday" => "Senin, ",
		"Tuesday"=> "Selasa, ",
		"Wednesday"=> "Rabu, ",
		"Thursday"=> "Kamis, ",
		"Friday"=> "Jum'at, ",
		"Saturday"=> "Sabtu, ",
		"Sunday"=> "Minggu, ",
		);
		$posted .= $dDay[$WeekDay];

		$posted .= " ". substr($StringDate,8,2)." ";
	
		if (substr($StringDate,5,2)=="01"):
			$posted .= "Januari";
		elseif (substr($StringDate,5,2)=="02"):
			$posted .= "Febuari";
		elseif (substr($StringDate,5,2)=="03"):
			$posted .= "Maret";
		elseif (substr($StringDate,5,2)=="04"):
			$posted .= "April";
		elseif (substr($StringDate,5,2)=="05"):
			$posted .= "Mei";
		elseif (substr($StringDate,5,2)=="06"):
			$posted .= "Juni";
		elseif (substr($StringDate,5,2)=="07"):
			$posted .= "Juli";
		elseif (substr($StringDate,5,2)=="08"):
			$posted .= "Agustus";
		elseif (substr($StringDate,5,2)=="09"):
			$posted .= "September";
		elseif (substr($StringDate,5,2)=="10"):
			$posted .= "Oktober";
		elseif (substr($StringDate,5,2)=="11"):
			$posted .= "November";
		elseif (substr($StringDate,5,2)=="12"):
			$posted .= "Desember";
		endif;
	
		$posted .= " ".substr($StringDate,0,4);
	
		return $posted;
	}
}

if ( ! function_exists('display_date2'))
{
	function display_date2($StringDate = '2000-01-01') {
		$posted = "";

		$WeekDay=date("l", mktime(0, 0, 0, substr($StringDate,5,2), substr($StringDate,8,2), substr($StringDate,0,4)));

		$posted .= "". substr($StringDate,8,2)." ";
	
		if (substr($StringDate,5,2)=="01"):
			$posted .= "Jan";
		elseif (substr($StringDate,5,2)=="02"):
			$posted .= "Feb";
		elseif (substr($StringDate,5,2)=="03"):
			$posted .= "Mar";
		elseif (substr($StringDate,5,2)=="04"):
			$posted .= "Apr";
		elseif (substr($StringDate,5,2)=="05"):
			$posted .= "Mei";
		elseif (substr($StringDate,5,2)=="06"):
			$posted .= "Jun";
		elseif (substr($StringDate,5,2)=="07"):
			$posted .= "Jul";
		elseif (substr($StringDate,5,2)=="08"):
			$posted .= "Agt";
		elseif (substr($StringDate,5,2)=="09"):
			$posted .= "Sep";
		elseif (substr($StringDate,5,2)=="10"):
			$posted .= "Okt";
		elseif (substr($StringDate,5,2)=="11"):
			$posted .= "Nov";
		elseif (substr($StringDate,5,2)=="12"):
			$posted .= "Des";
		endif;
	
		$posted .= " ".substr($StringDate,0,4);
	
		return $posted;
	}
}

if ( ! function_exists('GetMonthName'))
{
	function GetMonthName($iMonth, $sType, $lang = "id") {
		if ($lang == "en") {
			if ($sType == "shortdate") {
				$MonthIndonesia = array ('01'=>'Jan', '02'=>'Feb', '03'=>'Mar', '04'=>'Apr', '05'=>'May', '06'=>'Jun', '07'=>'Jul', '08'=>'Aug', '09'=>'Sep', '10'=>'Oct', '11'=>'Nov', '12'=>'Dec');

				return $MonthIndonesia[$iMonth];
			} if ($sType == "longdate") {
				$MonthIndonesia = array ('01'=>'January', '02'=>'February', '03'=>'March', '04'=>'April', '05'=>'May', '06'=>'June', '07'=>'July', '08'=>'August', '09'=>'September', '10'=>'October', '11'=>'November', '12'=>'December');

				return $MonthIndonesia[$iMonth];
			}
		} else if ($lang == "id") {
			if ($sType == "shortdate") {
				$MonthIndonesia = array ('01'=>'Jan', '02'=>'Feb', '03'=>'Mar', '04'=>'Apr', '05'=>'Mei', '06'=>'Jun', '07'=>'Jul', '08'=>'Agt', '09'=>'Sep', '10'=>'Okt', '11'=>'Nov', '12'=>'Des');

				return $MonthIndonesia[$iMonth];
			} if ($sType == "longdate") {
				$MonthIndonesia = array ('01'=>'Januari', '02'=>'Februari', '03'=>'Maret', '04'=>'April', '05'=>'Mei', '06'=>'Juni', '07'=>'Juli', '08'=>'Agustus', '09'=>'September', '10'=>'Oktober', '11'=>'November', '12'=>'Desember');

				return $MonthIndonesia[$iMonth];
			}
		}
	}

}

if ( ! function_exists('display_fulldate'))
{
	function display_fulldate($StringDate = '2000-01-01 12:58:13',$Mode = '1',$lang = "id") {
		$posted = "";

		$aDate		= substr($StringDate, 8, 2);
		$aMonth		= substr($StringDate, 5, 2);
		$aYear		= substr($StringDate, 0, 4);
		$aHour		= substr($StringDate, 11, 2);
		$aMinute	= substr($StringDate, 14, 2);
		$aSecond	= substr($StringDate, 17, 2);

		$WeekDay=date("l", mktime(0, 0, 0, $aMonth, $aDate, $aYear));
		if($lang=="id"):
			$dDay = array(
				"Monday" => "Senin, ",
				"Tuesday"=> "Selasa, ",
				"Wednesday"=> "Rabu, ",
				"Thursday"=> "Kamis, ",
				"Friday"=> "Jum'at, ",
				"Saturday"=> "Sabtu, ",
				"Sunday"=> "Minggu, ",
			);
		else:
			$dDay = array(
				"Monday" => "Monday, ",
				"Tuesday"=> "Tuesday, ",
				"Wednesday"=> "Wednesday, ",
				"Thursday"=> "Thursday, ",
				"Friday"=> "Friday, ",
				"Saturday"=> "Saturday, ",
				"Sunday"=> "Sunday, ",
			);
		endif;
		$posted .= $dDay[$WeekDay];

		switch ($Mode) {
			/* 23-03-2004 09:13:55 */
			case 1:
				$posted .= $aDate."-".$aMonth."-".$aYear." ".$aHour.":".$aMinute.":".$aSecond;
				break;
			/* 23 Mar 2004 09:13:55 */
			case 2:
				$posted .= $aDate." ".GetMonthName($aMonth, "shortdate", $lang)." ".$aYear." ".$aHour.":".$aMinute.":".$aSecond;
				break;
			/* 23 March 2004 09:13:55 */
			case 3:
				$posted .= $aDate." ".GetMonthName($aMonth, "longdate", $lang)." ".$aYear." ".$aHour.":".$aMinute.":".$aSecond;
				break;
			/* 23/03/2004 09:13:55 */
			case 4:
				$posted .= $aDate."/".$aMonth."/".$aYear." ".$aHour.":".$aMinute.":".$aSecond;
				break;
			/* 23/03/2004 09:13:55 */
			case 5:
				$posted .= $aDate."/".$aMonth."/".$aYear;
				break;
			/* 23 March 2005 */
			case 6:
				$posted .= $aDate." ".GetMonthName($aMonth, "longdate", $lang)." ".$aYear;
				break;
			/* 23 Mar 2004 */
			case 7:
				$posted .= $aDate." ".GetMonthName($aMonth, "shortdate", $lang)." ".$aYear;
				break;
			/* 23 March 2005 */
			case 8:
				$posted = "";
				$posted .= $aDate." ".GetMonthName($aMonth, "longdate", $lang)." ".$aYear;
				break;
			/* 2005, March 19 */
			case 9:
				$posted = "";
				$posted .= $aYear.", ".GetMonthName($aMonth, "longdate", $lang)." ".$aDate;
				break;
		}

		return $posted;
	}
}

if ( ! function_exists('breakdownDatepicker'))
{
	function breakdownDatePicker($StringDate = '12/13/2015',$addition = '1') {
		$posted = "";

		$explodeDate = explode("/",$StringDate);
		$posted .= $explodeDate[2]."-".$explodeDate[0]."-".$explodeDate[1];
		
		if($addition == '1') {
			$posted .= " ".date("H:i:s");
		}

		return $posted;
	}
}

if ( ! function_exists('prettyDate'))
{
	function prettyDate($date){
		$time = strtotime($date);
		$now = time()+21600;
		$ago = $now - $time;
		if($ago < 60){
			$when = round($ago);
			$s = ($when == 1)?"second":"seconds";
			return "$when $s ago";
		}elseif($ago < 3600){
			$when = round($ago / 60);
			$m = ($when == 1)?"minute":"minutes";
			return "$when $m ago";
		}elseif($ago >= 3600 && $ago < 86400){
			$when = round($ago / 60 / 60);
			$h = ($when == 1)?"hour":"hours";
			return "$when $h ago";
		}elseif($ago >= 86400 && $ago < 2629743.83){
			$when = round($ago / 60 / 60 / 24);
			$d = ($when == 1)?"day":"days";
			return "$when $d ago";
		}elseif($ago >= 2629743.83 && $ago < 31556926){
			$when = round($ago / 60 / 60 / 24 / 30.4375);
			$m = ($when == 1)?"month":"months";
			return "$when $m ago";
		}else{
			$when = round($ago / 60 / 60 / 24 / 365);
			$y = ($when == 1)?"year":"years";
			return "$when $y ago";
		}
	}
}

/* End of file custom_date_helper.php */
/* Location: ./system/helpers/custom_date_helper.php */