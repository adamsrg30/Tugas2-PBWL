<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
 *
 * Custom Display Date
 *
 */	
if ( ! function_exists('calculate_rate'))
{
	function calculate_rate($theAmount = '0.00',$currIDFrom = '1',$currIDTo = '1',$theDate,$theDB) {
		$ci =& get_instance();
		$ci->load->library('session');		
		
		$theReturn = "";
		//if $theDate empty then set today's date
		if(empty($theDate)) {
			$theDate = date("Y")."-".date("m")."-".date("d");
		} else {
			$theDate = $theDate;
		}
		
		//get latest exchange rate
		$ci->db->select('Multiplier');
		$ci->db->from('tilyan_'.$theDB.'_lookup_currency_multiplier');
		$ci->db->where('muID',$currIDFrom);
		$ci->db->where('datePublish <=',$theDate);
		$ci->db->order_by('datePublish','desc');
		$ci->db->limit(1,0);
		$currMultiplierFrom = $ci->db->get()->row_array();
		
		$ci->db->select('Multiplier');
		$ci->db->from('tilyan_'.$theDB.'_lookup_currency_multiplier');
		$ci->db->where('muID',$currIDTo);
		$ci->db->where('datePublish <=',$theDate);
		$ci->db->order_by('datePublish','desc');
		$ci->db->limit(1,0);
		$currMultiplierTo = $ci->db->get()->row_array();
		
		//check if choosen currency is bigger than default currency
		//if yes then multiply, if not then devide
		//note: default currency is later set when making new client
		if($currMultiplierFrom['Multiplier'] >= $currMultiplierTo['Multiplier']) {
			$theOperator = "multiply";
			$theReturn = $theAmount * $currMultiplierFrom['Multiplier'];
		} else {
			$theOperator = "devide";
			$theReturn = $theAmount / $currMultiplierTo['Multiplier'];
		}
		
		return $theReturn;
	}
}




/* End of file custom_date_helper.php */
/* Location: ./system/helpers/custom_date_helper.php */