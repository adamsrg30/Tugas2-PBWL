<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Global_model extends CI_Model {
	function __construct() {
		parent::__construct();
	}

	public function updateTbl($tableName, $theData, $theWhere) {
		return $this->db->update($tableName, $theData, $theWhere);
	}

	public function insertTbl($tableName, $theData) {
		$this->db->insert($tableName, $theData);
		
		return $this->db->insert_id();		
	}

	public function delTbl($tableName, $theWhere) {
		$this->db->delete($tableName, $theWhere); 
	}
	
	public function get_own_users_id() {
		$tmp = $this->session->userdata('login');
		$id = $tmp['usersID'];
		
		return $id;
	}





	
}  