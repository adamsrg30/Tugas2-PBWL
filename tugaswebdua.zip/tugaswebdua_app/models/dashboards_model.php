<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Dashboards_model extends CI_Model {
	function __construct() {
		parent::__construct();
	}

	public function countCategory(){
		$this->db->select("
				g.gol_id
			",false);
		$this->db->from('tb_golongan as g');
		return $this->db->count_all_results();
	}

	public function countUsers($user_role,$user_aktif){
		$this->db->select("
				u.user_id
			",false);
		$this->db->from('tb_users as u');
		$this->db->where('u.user_role',$user_role);
		$this->db->where('u.user_aktif',$user_aktif);
		return $this->db->count_all_results();
	}

	public function countSubscriber($pel_aktif){
		$this->db->select("
				p.pel_id
			",false);
		$this->db->from('tb_pelanggan as p');
		$this->db->where('p.pel_aktif',$pel_aktif);
		return $this->db->count_all_results();
	}






	
	
	
}  