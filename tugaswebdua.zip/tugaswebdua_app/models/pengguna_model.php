<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Pengguna_model extends CI_Model {
	function __construct() {
		parent::__construct();
	}

	public function get_list($tipe){ 
		$this->db->select("
				u.user_id, u.user_email, u.user_password, u.user_name, u.user_alamat, 
				u.user_hp, u.user_pos, u.user_role, u.user_aktif, u.created_at, u.updated_at, 
				(SELECT COUNT(p.pel_id) FROM tb_pelanggan as p WHERE p.pel_id_user = u.user_id) as countChild, 
				DATE_FORMAT(u.created_at, '%d %b %Y %H:%i:%s') as displayCreated, 
				DATE_FORMAT(u.updated_at, '%d %b %Y %H:%i:%s') as displayUpdated
			",false);
		$this->db->from('tb_users as u');
		$this->db->order_by('u.created_at','desc');
		$this->db->order_by('u.user_name','asc');
		if($tipe == "pulldown") {
			$this->db->where('u.user_aktif','1');
		}
		return $this->db->get()->result_array();
	}

	public function get_details($id){
		$this->db->select("
				u.user_id, u.user_email, u.user_password, u.user_name, u.user_alamat, 
				u.user_hp, u.user_pos, u.user_role, u.user_aktif, u.created_at, u.updated_at, 
				DATE_FORMAT(u.created_at, '%d %b %Y %H:%i:%s') as displayCreated, 
				DATE_FORMAT(u.updated_at, '%d %b %Y %H:%i:%s') as displayUpdated
		", false);
		$this->db->from('tb_users as u');
		$this->db->where("u.user_id",$id);
		return $this->db->get()->row_array();
	}
	










	
	
	
}  