<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Kategori_model extends CI_Model {
	function __construct() {
		parent::__construct();
	}

	public function get_list(){ 
		$this->db->select("
				g.gol_id, g.gol_kode, g.gol_nama, g.created_at, g.updated_at,  
				(SELECT COUNT(p.pel_id) FROM tb_pelanggan as p WHERE p.pel_id_gol = g.gol_id) as countChild, 
				DATE_FORMAT(g.created_at, '%d %b %Y %H:%i:%s') as displayCreated, 
				DATE_FORMAT(g.updated_at, '%d %b %Y %H:%i:%s') as displayUpdated
			",false);
		$this->db->from('tb_golongan as g');
		$this->db->order_by('g.gol_nama','asc');
		return $this->db->get()->result_array();
	}

	public function get_details($id){
		$this->db->select("
				g.gol_id, g.gol_kode, g.gol_nama, g.created_at, g.updated_at,  
				DATE_FORMAT(g.created_at, '%d %b %Y %H:%i:%s') as displayCreated, 
				DATE_FORMAT(g.updated_at, '%d %b %Y %H:%i:%s') as displayUpdated
		", false);
		$this->db->from('tb_golongan as g');
		$this->db->where("g.gol_id",$id);
		return $this->db->get()->row_array();
	}
	










	
	
	
}  