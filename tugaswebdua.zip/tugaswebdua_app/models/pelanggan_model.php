<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Pelanggan_model extends CI_Model {
	function __construct() {
		parent::__construct();
	}

	public function get_list($user_role,$user_id){ 
		$this->db->select("
				p.pel_id, p.pel_id_gol, p.pel_no, p.pel_nama, p.pel_alamat, p.pel_hp, p.pel_ktp, 
				p.pel_seri, p.pel_meteran, p.pel_aktif, p.pel_id_user, p.created_at, p.updated_at,  
				g.gol_kode, g.gol_nama, 
				u.user_name, 
				DATE_FORMAT(p.created_at, '%d %b %Y %H:%i:%s') as displayCreated, 
				DATE_FORMAT(p.updated_at, '%d %b %Y %H:%i:%s') as displayUpdated
			",false);
		$this->db->from('tb_pelanggan as p');
		$this->db->join('tb_golongan as g','g.gol_id = p.pel_id_gol','left');
		$this->db->join('tb_users as u','u.user_id = p.pel_id_user','left');
		if($user_role != 1) {
			$this->db->where('p.pel_id_user',$user_id);
		}
		$this->db->order_by('p.created_at','desc');
		$this->db->order_by('p.pel_id','desc');
		$this->db->order_by('p.pel_nama','asc');
		return $this->db->get()->result_array();
	}

	public function get_details($id){
		$this->db->select("
				p.pel_id, p.pel_id_gol, p.pel_no, p.pel_nama, p.pel_alamat, p.pel_hp, p.pel_ktp, 
				p.pel_seri, p.pel_meteran, p.pel_aktif, p.pel_id_user, p.created_at, p.updated_at,  
				g.gol_kode, g.gol_nama, 
				u.user_name, 
				DATE_FORMAT(p.created_at, '%d %b %Y %H:%i:%s') as displayCreated, 
				DATE_FORMAT(p.updated_at, '%d %b %Y %H:%i:%s') as displayUpdated
		", false);
		$this->db->from('tb_pelanggan as p');
		$this->db->join('tb_golongan as g','g.gol_id = p.pel_id_gol','left');
		$this->db->join('tb_users as u','u.user_id = p.pel_id_user','left');
		$this->db->where("p.pel_id",$id);
		return $this->db->get()->row_array();
	}
	

	
	



//front-end section	
	public function getData($rowno,$rowperpage){ //$rowno = top row position at current page,$rowperpage = number of records shown
		$this->db->select("
				c.theID, c.theDate, c.theTitle, c.theLead, c.theContent, c.theTags, c.createdBy, c.Status, c.authorName, c.theFile, c.theThumb, 
				DATE_FORMAT(c.theDate, '%d') as dayTheDate,
				DATE_FORMAT(c.theDate, '%m') as monthTheDate,
				DATE_FORMAT(c.theDate, '%Y') as yearTheDate,
				a.adminName, c.dateCreated, c.lastModifiedDate, 
				a2.adminName as ModifiedName,
				DATE_FORMAT(c.theDate, '%d %b %Y') as displayTheDate,
				DATE_FORMAT(c.dateCreated, '%d %b %Y %H:%i:%s') as displayDateCreated, 
				DATE_FORMAT(c.lastModifiedDate, '%d %b %Y %H:%i:%s') as displayDateModified
			",false);
		$this->db->from('tbl_content as c');
		$this->db->join('tbl_admmembers as a','a.adminID = c.createdBy','left');
		$this->db->join('tbl_admmembers as a2','a2.adminID = c.lastModifiedBy','left');
		$this->db->where('c.Status','1');
		$this->db->order_by('c.theDate','desc');
		$this->db->order_by('c.theID','desc');
		$this->db->limit($rowperpage, $rowno);
		$this->db->where('c.contentType','news');
		return $this->db->get()->result_array();
	}

	public function getOthers($id,$count){ //$id = if not 0 then select records other than id given, $count = number of records shown
		$this->db->select("
				c.theID, c.theDate, c.theTitle, c.theLead, c.theContent, c.theTags, c.createdBy, c.Status, c.authorName, c.theFile, c.theThumb, 
				DATE_FORMAT(c.theDate, '%d') as dayTheDate,
				DATE_FORMAT(c.theDate, '%m') as monthTheDate,
				DATE_FORMAT(c.theDate, '%Y') as yearTheDate,
				a.adminName, c.dateCreated, c.lastModifiedDate, 
				a2.adminName as ModifiedName,
				DATE_FORMAT(c.theDate, '%d %b %Y') as displayTheDate,
				DATE_FORMAT(c.dateCreated, '%d %b %Y %H:%i:%s') as displayDateCreated, 
				DATE_FORMAT(c.lastModifiedDate, '%d %b %Y %H:%i:%s') as displayDateModified
			",false);
		$this->db->from('tbl_content as c');
		$this->db->join('tbl_admmembers as a','a.adminID = c.createdBy','left');
		$this->db->join('tbl_admmembers as a2','a2.adminID = c.lastModifiedBy','left');
		if($id != 0) {
			$this->db->where('theID <>',$id);
			$this->db->where('theID <',$id);
		}
		$this->db->where('c.Status','1');
		$this->db->where('c.contentType','news');
		$this->db->order_by('c.theDate','desc');
		$this->db->order_by('c.theID','desc');
		$this->db->limit($count, 0);
		return $this->db->get()->result_array();
	}

	public function getDistinctYear(){ 
		$this->db->select("
				YEAR(theDate) as theYear
			",false);
		$this->db->distinct();
		$this->db->from('tbl_content');
		$this->db->where('Status','1');
		$this->db->order_by('theYear','desc');
		$this->db->where('contentType','news');
		return $this->db->get()->result_array();
	}

	public function getDataArsip($year,$rowno,$rowperpage){ //$rowno = top row position at current page,$rowperpage = number of records shown
		$this->db->select("
				c.theID, c.theDate, c.theTitle, c.theLead, c.theContent, c.theTags, c.createdBy, c.Status, c.authorName, c.theFile, c.theThumb, 
				a.adminName, c.dateCreated, c.lastModifiedDate, 
				a2.adminName as ModifiedName,
				DATE_FORMAT(c.theDate, '%d %b %Y') as displayTheDate,
				DATE_FORMAT(c.dateCreated, '%d %b %Y %H:%i:%s') as displayDateCreated, 
				DATE_FORMAT(c.lastModifiedDate, '%d %b %Y %H:%i:%s') as displayDateModified
			",false);
		$this->db->from('tbl_content as c');
		$this->db->join('tbl_admmembers as a','a.adminID = c.createdBy','left');
		$this->db->join('tbl_admmembers as a2','a2.adminID = c.lastModifiedBy','left');
		$this->db->where('c.Status','1');
		if($year != 0) {
			$this->db->where('YEAR(c.theDate)',$year);
		}
		$this->db->order_by('c.theDate','desc');
		$this->db->order_by('c.theID','desc');
		if($rowperpage != 0) {
			$this->db->limit($rowperpage, $rowno);
		}
		$this->db->where('c.contentType','news');
		return $this->db->get()->result_array();
	}










	
	
	
}  