<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

//$root = "http://".HOST_DOMAIN;
//$root .= str_replace(basename($_SERVER['SCRIPT_NAME']), "", $_SERVER['SCRIPT_NAME']);

$config['base_url'] = "http://".$_SERVER['SERVER_NAME']."/tugaswebdua";


//site config
$config['site_name'] 	= 'Tugas Web II by Adam Malik Siregar';

$config['css_path'] 		= $config['base_url'].'/tugaswebdua_html/assets/css/';
$config['img_path'] 		= $config['base_url'].'/tugaswebdua_html/assets/img/';
$config['fonts_path'] 		= $config['base_url'].'/tugaswebdua_html/assets/fonts/';
$config['icons_path'] 		= $config['base_url'].'/tugaswebdua_html/assets/icons/';

$config['system_name']		= 'TUGAS WEB II';



  
/* End of file app_config.php */
/* Location: ./intranet_app/config/app_config.php */
