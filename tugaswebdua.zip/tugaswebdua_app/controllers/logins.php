<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Logins extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -  
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in 
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */


	public function index() {
		$SessionLogin = $this->session->userdata("login");

//		if($SessionLogin['loggedIn'] == false) {
//			redirect(base_url()."webadmins/");
//		}
		
		$data['assets_path_img'] 	= $this->config->item("img_path");
		$data['assets_path_css'] 	= $this->config->item("css_path");
		$data['assets_path_fonts'] 	= $this->config->item("fonts_path");
		$data['assets_path_icons'] 	= $this->config->item("icons_path");
		$data['site_name'] 			= $this->config->item("site_name");
		$data['system_name'] 		= $this->config->item("system_name");
		
		$this->load->view('logins/index',$data);
	}

	public function dologin() {
		$this->load->model('Global_model','global_model');

		$theusername = $this->input->post('username');
		$thepassword = $this->input->post('password');
		
		//check member exists
		$this->db->select("
				user_id, user_email, user_password, user_name, user_role, user_aktif, user_pos, user_hp
			", false);
		$this->db->from('tb_users');
		$this->db->where('user_aktif','1');
		$this->db->where('user_email',$theusername);

		$query = $this->db->get();
		$checkMember = $query->row_array();
		
		if(!empty($checkMember)) {
			//member exists
			$loginDate = date('Y-m-d H:i:s', strtotime('+6 hours'));
			$memberPass = $checkMember['user_password'];
			
			if($thepassword == $memberPass) {
				$letgo = 1;
			} else {
				$letgo = 0;
			}
			
			if($letgo) {
				$checkMember['loggedIn'] = true;
				
				if($checkMember['user_role'] == "1") {
					$checkMember['txtRole'] = "Admin";
				} else {
					$checkMember['txtRole'] = "User";
				}

				$this->session->set_userdata('login',$checkMember);
				
/*
				$showSession = $this->session->userdata('login');
				echo "<pre>";
				print_r($showSession);
				echo "========================================<br/>";
				exit;
*/
				$referred_from = $this->session->userdata('main_referred_from');
				redirect($referred_from, 'refresh');
			} else {
//				echo "member exists, password wrong";
//				exit;
				$this->session->set_userdata('main_failed_login', true);
				$referred_from = $this->session->userdata('main_referred_from');
				redirect($referred_from, 'refresh');
			}
		} else {
//			echo "member not exists";
//			exit;
			$this->session->set_userdata('main_failed_login', true);
			$referred_from = $this->session->userdata('main_referred_from');
			redirect($referred_from, 'refresh');
		}
	}

	public function logout(){
        if($this->session->userdata('login')){
            $this->session->unset_userdata('login');
			$this->session->unset_userdata('main_referred_from');
            redirect($_SERVER['HTTP_REFERER'], 'refresh');
        }
		redirect(base_url());
    }





}

/* End of file home.php */
/* Location: ./application/controllers/home.php */