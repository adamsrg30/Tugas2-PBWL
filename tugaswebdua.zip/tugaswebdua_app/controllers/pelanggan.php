<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Pelanggan extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -  
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in 
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */


	public function index() {
		$this->session->unset_userdata('main_referred_from');
		$this->session->set_userdata('main_referred_from', current_url());
		
		$SessionLogin = $this->session->userdata('login');
		$data['SessionLogin']		= $SessionLogin;
		
		if(empty($SessionLogin)) {
			redirect(base_url()."logins/");
		}

		$this->load->helper('text');
		$this->load->model('Global_model','global_model');
		$this->load->model('Pelanggan_model','pelanggan_model');

		$data['assets_path_img'] 	= $this->config->item("img_path");
		$data['assets_path_css'] 	= $this->config->item("css_path");
		$data['assets_path_fonts'] 	= $this->config->item("fonts_path");
		$data['assets_path_icons'] 	= $this->config->item("icons_path");
		$data['site_name'] 			= $this->config->item("site_name");
		$data['system_name'] 		= $this->config->item("system_name");
		
		$data['mainlist'] 		= $this->pelanggan_model->get_list($SessionLogin['user_role'],$SessionLogin['user_id']);
//		echo $this->db->last_query();
//		exit;
		
		$this->load->view('pelanggan/thelist',$data);
	}

	public function add() {
		$this->session->unset_userdata('main_referred_from');
		$this->session->set_userdata('main_referred_from', current_url());
		
		$SessionLogin = $this->session->userdata('login');
		$data['SessionLogin']		= $SessionLogin;
		
		if(empty($SessionLogin)) {
			redirect(base_url()."logins/");
		}

		$this->load->helper('text');
		$this->load->model('Global_model','global_model');
		$this->load->model('Kategori_model','kategori_model');
		$this->load->model('Pengguna_model','pengguna_model');
		$this->load->model('Pelanggan_model','pelanggan_model');

		$data['assets_path_img'] 	= $this->config->item("img_path");
		$data['assets_path_css'] 	= $this->config->item("css_path");
		$data['assets_path_fonts'] 	= $this->config->item("fonts_path");
		$data['assets_path_icons'] 	= $this->config->item("icons_path");
		$data['site_name'] 			= $this->config->item("site_name");
		$data['system_name'] 		= $this->config->item("system_name");

		if($this->input->post('action') == "add") {
			//insert data
			$tableName = "tb_pelanggan";
			$insertData = array(
				'pel_id_gol' => $this->input->post('pel_id_gol'),
				'pel_no' => $this->input->post('pel_no'),
				'pel_nama' => $this->input->post('pel_nama'),
				'pel_alamat' => $this->input->post('pel_alamat'),
				'pel_hp' => $this->input->post('pel_hp'),
				'pel_ktp' => $this->input->post('pel_ktp'),
				'pel_seri' => $this->input->post('pel_seri'),
				'pel_meteran' => $this->input->post('pel_meteran'),
				'pel_aktif' => $this->input->post('pel_aktif'),
				'pel_id_user' => $this->input->post('pel_id_user')
			);
			$tblInsertReturn = $this->global_model->insertTbl($tableName,$insertData);

			redirect(base_url().'pelanggan');
		}

		$data['kategori'] 	= $this->kategori_model->get_list();
		$data['pengguna'] 	= $this->pengguna_model->get_list("pulldown");

		$this->load->view('pelanggan/add',$data);
	}

	public function edit($id) {
		$this->session->unset_userdata('main_referred_from');
		$this->session->set_userdata('main_referred_from', current_url());
		
		$SessionLogin = $this->session->userdata('login');
		$data['SessionLogin']		= $SessionLogin;
		
		if(empty($SessionLogin)) {
			redirect(base_url()."logins/");
		}

		$this->load->helper('text');
		$this->load->model('Global_model','global_model');
		$this->load->model('Kategori_model','kategori_model');
		$this->load->model('Pengguna_model','pengguna_model');
		$this->load->model('Pelanggan_model','pelanggan_model');

		$data['assets_path_img'] 	= $this->config->item("img_path");
		$data['assets_path_css'] 	= $this->config->item("css_path");
		$data['assets_path_fonts'] 	= $this->config->item("fonts_path");
		$data['assets_path_icons'] 	= $this->config->item("icons_path");
		$data['site_name'] 			= $this->config->item("site_name");
		$data['system_name'] 		= $this->config->item("system_name");

		if($this->input->post('action') == "edit") {
			$tableName = "tb_pelanggan";
			$updateData = array(
				'pel_id_gol' => $this->input->post('pel_id_gol'),
				'pel_no' => $this->input->post('pel_no'),
				'pel_nama' => $this->input->post('pel_nama'),
				'pel_alamat' => $this->input->post('pel_alamat'),
				'pel_hp' => $this->input->post('pel_hp'),
				'pel_ktp' => $this->input->post('pel_ktp'),
				'pel_seri' => $this->input->post('pel_seri'),
				'pel_meteran' => $this->input->post('pel_meteran'),
				'pel_aktif' => $this->input->post('pel_aktif'),
				'pel_id_user' => $this->input->post('pel_id_user'),
				'updated_at' => date("Y-m-d H:i:s", strtotime('+6 hours')),
			);
			$theWhere = array(
				'pel_id' => $this->uri->segment(3)
			);
			$this->global_model->updateTbl($tableName,$updateData,$theWhere);
			
			redirect(base_url().'pelanggan');
		}

		$data['kategori'] 	= $this->kategori_model->get_list();
		$data['pengguna'] 	= $this->pengguna_model->get_list("pulldown");
		$data['details'] 	= $this->pelanggan_model->get_details($this->uri->segment(3));
//		echo $this->db->last_query();
//		exit;

		$this->load->view('pelanggan/edit',$data);
	}
	
	public function delete($id) {
		$this->session->unset_userdata('main_referred_from');
		$this->session->set_userdata('main_referred_from', current_url());
		
		$SessionLogin = $this->session->userdata('login');
		$data['SessionLogin']		= $SessionLogin;
		
		if(empty($SessionLogin)) {
			redirect(base_url()."logins/");
		}

		$this->load->model('Global_model','global_model');

		$tableName = "tb_pelanggan";
		$theWhere = array(
			'pel_id' => $id
		);
		$this->global_model->delTbl($tableName, $theWhere);
		
		redirect(base_url().'pelanggan');
   }


	



}

/* End of file pelanggan.php */
/* Location: ./application/controllers/pelanggan.php */