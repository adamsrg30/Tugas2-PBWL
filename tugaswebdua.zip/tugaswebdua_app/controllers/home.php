<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Home extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -  
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in 
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */


	public function index() {
		$this->session->unset_userdata('main_referred_from');
		$this->session->set_userdata('main_referred_from', current_url());
		
		$SessionLogin = $this->session->userdata('login');
		$data['SessionLogin']		= $SessionLogin;
		
		if(empty($SessionLogin)) {
			redirect(base_url()."logins/");
		}

		$this->load->helper('text');
		$this->load->model('Dashboards_model','dashboards_model');

		$data['assets_path_img'] 	= $this->config->item("img_path");
		$data['assets_path_css'] 	= $this->config->item("css_path");
		$data['assets_path_fonts'] 	= $this->config->item("fonts_path");
		$data['assets_path_icons'] 	= $this->config->item("icons_path");
		$data['site_name'] 			= $this->config->item("site_name");
		$data['system_name'] 		= $this->config->item("system_name");
		
		$data['countCategory'] 				= $this->dashboards_model->countCategory();
		$data['countUsersAdminActive'] 		= $this->dashboards_model->countUsers(1,1); //role, aktif
		$data['countUsersAdminNotActive'] 	= $this->dashboards_model->countUsers(1,0); //role, aktif
		$data['countUsersUserActive'] 		= $this->dashboards_model->countUsers(2,1); //role, aktif
		$data['countUsersUserNotActive'] 	= $this->dashboards_model->countUsers(2,0); //role, aktif
		$data['countSubscriberActive'] 		= $this->dashboards_model->countSubscriber("Y"); //aktif
		$data['countSubscriberNotActive'] 	= $this->dashboards_model->countSubscriber("N"); //aktif
		
		$this->load->view('index',$data);
	}





}

/* End of file home.php */
/* Location: ./application/controllers/home.php */