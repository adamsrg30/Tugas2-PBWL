<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Pengguna extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -  
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in 
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */


	public function index() {
		$this->session->unset_userdata('main_referred_from');
		$this->session->set_userdata('main_referred_from', current_url());
		
		$SessionLogin = $this->session->userdata('login');
		$data['SessionLogin']		= $SessionLogin;
		
		if(empty($SessionLogin)) {
			redirect(base_url()."logins/");
		} elseif($SessionLogin['user_role'] != 1) {
			redirect(base_url());
		}

		$this->load->helper('text');
		$this->load->model('Global_model','global_model');
		$this->load->model('Pengguna_model','pengguna_model');

		$data['assets_path_img'] 	= $this->config->item("img_path");
		$data['assets_path_css'] 	= $this->config->item("css_path");
		$data['assets_path_fonts'] 	= $this->config->item("fonts_path");
		$data['assets_path_icons'] 	= $this->config->item("icons_path");
		$data['site_name'] 			= $this->config->item("site_name");
		$data['system_name'] 		= $this->config->item("system_name");
		
		$user_id = 0;
		$data['mainlist'] 		= $this->pengguna_model->get_list("all");
//		echo $this->db->last_query();
//		exit;
		
		$this->load->view('pengguna/thelist',$data);
	}

	public function add() {
		$this->session->unset_userdata('main_referred_from');
		$this->session->set_userdata('main_referred_from', current_url());
		
		$SessionLogin = $this->session->userdata('login');
		$data['SessionLogin']		= $SessionLogin;
		
		if(empty($SessionLogin)) {
			redirect(base_url()."logins/");
		} elseif($SessionLogin['user_role'] != 1) {
			redirect(base_url());
		}

		$this->load->helper('text');
		$this->load->model('Global_model','global_model');
		$this->load->model('Pengguna_model','Pengguna_model');

		$data['assets_path_img'] 	= $this->config->item("img_path");
		$data['assets_path_css'] 	= $this->config->item("css_path");
		$data['assets_path_fonts'] 	= $this->config->item("fonts_path");
		$data['assets_path_icons'] 	= $this->config->item("icons_path");
		$data['site_name'] 			= $this->config->item("site_name");
		$data['system_name'] 		= $this->config->item("system_name");

		if($this->input->post('action') == "add") {
			//insert data
			$tableName = "tb_users";
			$insertData = array(
				'user_email' => $this->input->post('user_email'),
				'user_name' => $this->input->post('user_name'),
				'user_password' => $this->input->post('user_password'),
				'user_alamat' => $this->input->post('user_alamat'),
				'user_hp' => $this->input->post('user_hp'),
				'user_pos' => $this->input->post('user_pos'),
				'user_role' => $this->input->post('user_role'),
				'user_aktif' => $this->input->post('user_aktif')
			);
			$tblInsertReturn = $this->global_model->insertTbl($tableName,$insertData);

			redirect(base_url().'pengguna');
		}

		$this->load->view('pengguna/add',$data);
	}

	public function edit($id) {
		$this->session->unset_userdata('main_referred_from');
		$this->session->set_userdata('main_referred_from', current_url());
		
		$SessionLogin = $this->session->userdata('login');
		$data['SessionLogin']		= $SessionLogin;
		
		if(empty($SessionLogin)) {
			redirect(base_url()."logins/");
		} elseif($SessionLogin['user_role'] != 1) {
			redirect(base_url());
		}

		$this->load->helper('text');
		$this->load->model('Global_model','global_model');
		$this->load->model('Pengguna_model','pengguna_model');

		$data['assets_path_img'] 	= $this->config->item("img_path");
		$data['assets_path_css'] 	= $this->config->item("css_path");
		$data['assets_path_fonts'] 	= $this->config->item("fonts_path");
		$data['assets_path_icons'] 	= $this->config->item("icons_path");
		$data['site_name'] 			= $this->config->item("site_name");
		$data['system_name'] 		= $this->config->item("system_name");

		if($this->input->post('action') == "edit") {
			$tableName = "tb_users";
			$updateData = array(
				'user_email' => $this->input->post('user_email'),
				'user_password' => $this->input->post('user_password'),
				'user_name' => $this->input->post('user_name'),
				'user_alamat' => $this->input->post('user_alamat'),
				'user_hp' => $this->input->post('user_hp'),
				'user_pos' => $this->input->post('user_pos'),
				'user_role' => $this->input->post('user_role'),
				'user_aktif' => $this->input->post('user_aktif'),
				'updated_at' => date('Y-m-d H:i:s', strtotime('+6 hours'))
			);
			$theWhere = array(
				'user_id' => $this->uri->segment(3)
			);
			$this->global_model->updateTbl($tableName,$updateData,$theWhere);
			
			redirect(base_url().'pengguna');
		}

		$data['details'] 	= $this->pengguna_model->get_details($this->uri->segment(3));
//		echo $this->db->last_query();
//		exit;

		$this->load->view('pengguna/edit',$data);
	}
	
	public function delete($id) {
		$this->session->unset_userdata('main_referred_from');
		$this->session->set_userdata('main_referred_from', current_url());
		
		$SessionLogin = $this->session->userdata('login');
		$data['SessionLogin']		= $SessionLogin;
		
		if(empty($SessionLogin)) {
			redirect(base_url()."logins/");
		} elseif($SessionLogin['user_role'] != 1) {
			redirect(base_url());
		}

		$this->load->model('Global_model','global_model');

		$tableName = "tb_users";
		$theWhere = array(
			'user_id' => $id
		);
		$this->global_model->delTbl($tableName, $theWhere);
		
		redirect(base_url().'pengguna');
	}



	



}

/* End of file pengguna.php */
/* Location: ./application/controllers/pengguna.php */