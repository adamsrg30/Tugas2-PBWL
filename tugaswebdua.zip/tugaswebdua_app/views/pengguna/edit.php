<!DOCTYPE html>
<html lang="en">

<head>
      <meta charset="UTF-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title><?php echo $site_name; ?> - Users</title>

      <link type="text/css" rel="stylesheet" href="<?php echo $assets_path_css; ?>style.css">
	  <link type="text/css" rel="stylesheet" href="<?php echo $assets_path_fonts;?>fonts.css">
	  <link type="text/css" rel="stylesheet" href="<?php echo $assets_path_icons;?>icomoon/icomoon.css">
</head>

<body>

<?php $this->load->view('panels/aside'); ?>

      <main>
          <article>
<h2>EDIT USERS</h2>

<form action="<?php echo base_url()."pengguna/edit/".$details['user_id']; ?>" method="post">
	<input type="hidden" name="action" value="edit" />
    <table>
        <tr>
            <td>Name</td>
            <td><input type="text" name="user_name" value="<?php echo $details['user_name']; ?>" required></td>
        </tr>
        <tr>
            <td>Email</td>
            <td><input type="text" name="user_email" value="<?php echo $details['user_email']; ?>" required></td>
        </tr>
        <tr>
            <td>Password</td>
            <td><input type="text" name="user_password" value="<?php echo $details['user_password']; ?>" required></td>
        </tr>
        <tr>
            <td>Address</td>
            <td><textarea name="user_alamat" id="" cols="58" rows="10" required><?php echo nl2br($details['user_alamat']); ?></textarea></td>
        </tr>
        <tr>
            <td>Handphone</td>
            <td><input type="text" name="user_hp" value="<?php echo $details['user_hp']; ?>"></td>
        </tr>
        <tr>
            <td>Position</td>
            <td><input type="text" name="user_pos" value="<?php echo $details['user_pos']; ?>" maxlength="5"></td>
        </tr>
        <tr>
            <td>Role</td>
            <td>
				<select name="user_role" required>
					<option value="1"<?php echo (($details['user_role'] == 1) ? " selected=\"selected\"" : ""); ?>>Admin</option>
					<option value="2"<?php echo (($details['user_role'] == 2) ? " selected=\"selected\"" : ""); ?>>User</option>
				</select>
			</td>
        </tr>
        <tr>
            <td>Active</td>
            <td>
				<select name="user_aktif" required>
					<option value="1"<?php echo (($details['user_aktif'] == 1) ? " selected=\"selected\"" : ""); ?>>YES</option>
					<option value="0"<?php echo (($details['user_aktif'] == 0) ? " selected=\"selected\"" : ""); ?>>NO</option>
				</select>
			</td>
        </tr>
        <tr>
            <td></td>
            <td>
				<input type="submit" name="btn_simpan" class="btn" value="SAVE">
				<input type="button" name="btn_balik" class="btn" onClick="javascript:document.location.href='<?php echo base_url()."pengguna/"; ?>'" value="CANCEL">
			</td>
        </tr>
    </table>
</form>
		  </article>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<?php $this->load->view('panels/footer'); ?>
      </main>

</body>

</html>