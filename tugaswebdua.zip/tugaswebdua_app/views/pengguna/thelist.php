<!DOCTYPE html>
<html lang="en">

<head>
      <meta charset="UTF-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title><?php echo $site_name; ?> - Users</title>

      <link type="text/css" rel="stylesheet" href="<?php echo $assets_path_css; ?>style.css">
	  <link type="text/css" rel="stylesheet" href="<?php echo $assets_path_fonts;?>fonts.css">
	  <link type="text/css" rel="stylesheet" href="<?php echo $assets_path_icons;?>icomoon/icomoon.css">
</head>

<body>

<?php $this->load->view('panels/aside'); ?>

      <main>
          <article>
<h2>USERS</h2>

<button id="tableAdd_button" type="button" class="btn" onclick="document.location.href='<?php echo base_url()."pengguna/add"; ?>';"><i class="icon-plus3"></i> Add New User</button>
<?php
if(!empty($mainlist)) {		  
?>
<table>
    <tr>
        <th>NO</th>
        <th>NAME</th>
        <th>EMAIL</th>
        <th>HANDPHONE</th>
        <th>POSITION</th>
        <th>ACTIVE</th>
        <th>ACTION</th>
    </tr>
    <?php
	$no = 1;
	foreach ($mainlist as $ml) {
		if($ml['user_aktif'] == 1) {
			$txtActive = "Active";
		} else {
			$txtActive = "Not Active";
		}
	?>
    <tr>
        <td><?php echo $no; ?></td>
        <td><?php echo ucfirst($ml['user_name']); ?></td>
        <td><?php echo $ml['user_email']; ?></td>
        <td><?php echo $ml['user_hp']; ?></td>
        <td><?php echo ucfirst($ml['user_pos']); ?></td>
        <td><?php echo $txtActive; ?></td>
        <td>
			<button id="tableAdd_button" type="button" class="btn m-r-10" onclick="document.location.href='<?php echo base_url()."pengguna/edit/".$ml['user_id']; ?>';"> Edit</button>&nbsp;
			<button id="tableAdd_button" type="button" class="btn m-r-10" onclick="document.location.href='<?php echo base_url()."pengguna/delete/".$ml['user_id']; ?>';"<?php echo (($ml['countChild'] != 0) ? " disabled style=\"background-color:#f3f3f3; border-color:#f3f3f3; color:#000;\"" : ""); ?>> Delete</button>
		</td>
	</tr>
    <?php 
		$no++;	
	}
	?>
</table>
<?php
}
?>


		  </article>

<?php $this->load->view('panels/footer'); ?>
      </main>

</body>

</html>