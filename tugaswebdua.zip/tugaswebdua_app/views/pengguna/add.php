<!DOCTYPE html>
<html lang="en">

<head>
      <meta charset="UTF-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title><?php echo $site_name; ?> - Users</title>

      <link type="text/css" rel="stylesheet" href="<?php echo $assets_path_css; ?>style.css">
	  <link type="text/css" rel="stylesheet" href="<?php echo $assets_path_fonts;?>fonts.css">
	  <link type="text/css" rel="stylesheet" href="<?php echo $assets_path_icons;?>icomoon/icomoon.css">
</head>

<body>

<?php $this->load->view('panels/aside'); ?>

      <main>
          <article>
<h2>ADD NEW USERS</h2>

<form action="<?php echo base_url()."pengguna/add"; ?>" method="post">
	<input type="hidden" name="action" value="add" />
    <table>
        <tr>
            <td>Name</td>
            <td><input type="text" name="user_name" required></td>
        </tr>
        <tr>
            <td>Email</td>
            <td><input type="text" name="user_email" required></td>
        </tr>
        <tr>
            <td>Password</td>
            <td><input type="text" name="user_password" required></td>
        </tr>
        <tr>
            <td>Address</td>
            <td><textarea name="user_alamat" id="" cols="58" rows="10" required></textarea></td>
        </tr>
        <tr>
            <td>Handphone</td>
            <td><input type="text" name="user_hp"></td>
        </tr>
        <tr>
            <td>Position</td>
            <td><input type="text" name="user_pos" maxlength="5"></td>
        </tr>
        <tr>
            <td>Role</td>
            <td>
				<select name="user_role" required>
					<option value="1">Admin</option>
					<option value="2">User</option>
				</select>
			</td>
        </tr>
        <tr>
            <td>Active</td>
            <td>
				<select name="user_aktif" required>
					<option value="1">YES</option>
					<option value="0">NO</option>
				</select>
			</td>
        </tr>
        <tr>
            <td></td>
            <td>
				<input type="submit" name="btn_simpan" class="btn" value="SAVE">
				<input type="button" name="btn_balik" class="btn" onClick="javascript:document.location.href='<?php echo base_url()."pengguna/"; ?>'" value="CANCEL">
			</td>
        </tr>
    </table>
</form>
		  </article>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<?php $this->load->view('panels/footer'); ?>
      </main>

</body>

</html>