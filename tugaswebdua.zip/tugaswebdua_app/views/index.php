<!DOCTYPE html>
<html lang="en">

<head>
      <meta charset="UTF-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title><?php echo $site_name; ?></title>

      <link type="text/css" rel="stylesheet" href="<?php echo $assets_path_css; ?>style.css">
	  <link type="text/css" rel="stylesheet" href="<?php echo $assets_path_fonts;?>fonts.css">
	  <link type="text/css" rel="stylesheet" href="<?php echo $assets_path_icons;?>icomoon/icomoon.css">
</head>

<body>

<?php $this->load->view("panels/aside"); ?>
	
      <main>
          <article>
<h2>Dashboard</h2>

<div class="info">Selamat datang, <strong><?php echo $SessionLogin['user_name']; ?></strong></div>
<div style="margin: 26px; font-size: 18px;">
	<p>Total Category : <strong><?php echo $countCategory; ?></strong></p>
	<p>Total Users : <strong><?php echo $countUsersAdminActive+$countUsersAdminNotActive+$countUsersUserActive+$countUsersUserNotActive; ?></strong>
		<br><strong><?php echo $countUsersAdminActive+$countUsersAdminNotActive ?></strong> Admins ( <?php echo "<strong>".$countUsersAdminActive."</strong> Active and <strong>". $countUsersAdminNotActive ."</strong> Not Active"; ?> )
		<br><strong><?php echo $countUsersUserActive+$countUsersUserNotActive ?></strong> Users ( <?php echo "<strong>".$countUsersUserActive."</strong> Active and <strong>". $countUsersUserNotActive ."</strong> Not Active"; ?> )
	</p>
	<p>Total Subscriber : <strong><?php echo $countSubscriberActive+$countSubscriberNotActive; ?></strong>
		<br>( <?php echo "<strong>".$countSubscriberActive."</strong> Active and <strong>". $countSubscriberNotActive ."</strong> Not Active"; ?> )
	</p>
</div>
		  </article>

<?php $this->load->view('panels/footer'); ?>
	</main>

</body>

</html>