			<!-- Footer -->
			<div class="footer text-size-mini">
				&copy; <?php echo (date("Y") == 2023) ? "2023" : "2023 - ".date("Y"); ?>&nbsp;&nbsp;&nbsp;::&nbsp;&nbsp;&nbsp;<span style="color:#1e3b71;"><?php echo $site_name; ?></span>
			</div>
			<!-- /footer -->
