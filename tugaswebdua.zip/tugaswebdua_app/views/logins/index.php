<!DOCTYPE html>
<html lang="en">

<head>
      <meta charset="UTF-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title><?php echo $site_name; ?></title>

      <link type="text/css" rel="stylesheet" href="<?php echo $assets_path_css; ?>style.css">
	  <link type="text/css" rel="stylesheet" href="<?php echo $assets_path_fonts;?>fonts.css">
	  <link type="text/css" rel="stylesheet" href="<?php echo $assets_path_icons;?>icomoon/icomoon.css">
</head>

<body style="height:100%;">

	<div class="login-container">

		<!-- Page content -->
		<div class="page-content">

			<!-- Simple login form -->
			<form id="frmLogin" action="<?php echo base_url(); ?>logins/dologin" method="post">			
				<div class="login-form no-border no-border-radius">							
					<div class="welcome p-t-20" style="background-color:#1e3b71; border-color:#1e3b71; color:#fff;">						
                        <div class="welcome-text"><?php echo $system_name; ?></div>
						<div class="welcome-text text-size-huge text-light" style="padding-top:3px;">Please sign in</div>
					</div>
					<div class="panel panel-flat no-border">
						<div class="panel-body p-b-5">
							<?php /*?><div id="loginLoader" class="load-bar">
								<div class="bar"></div>
								<div class="bar"></div>
								<div class="bar"></div>
							</div><?php */?>
							<?php
							if($this->session->userdata('main_failed_login') == true){
								$this->session->unset_userdata('main_failed_login');
							?>
							<div id="loginResult" class="alert alert-danger alert-styled-left alert-bordered">
								<span class="text-semibold">Login Failed.</span> Please try again.
							</div>
							<?php
							}
							?>
							<?php
							if($this->session->userdata('main_failed_login_pass') == true){
								$this->session->unset_userdata('main_failed_login_pass');
							?>
							<div id="loginResult" class="alert alert-danger alert-styled-left alert-bordered">
								<span class="text-semibold">Incorrect Password.</span> Please try again.
							</div>
							<?php
							}
							if ($this->session->userdata('main_username') != "") {
								$returnUsername = $this->session->userdata('main_username');
							} else {
								$returnUsername = "";
							}
							$this->session->unset_userdata('main_username');
							?>
							<div class="form-group">
								<input type="text" class="form-control" placeholder="Email Address" name="username" id="username" value="<?php echo (isset($returnUsername) ? $returnUsername : ""); ?>" required>							
							</div>

							<div class="form-group">
								<input type="password" class="form-control" placeholder="Password" name="password" id="password" required>							
							</div>

							<div class="login-options">
								<div class="row">
									<?php /*?><div class="col-sm-6 col-xs-6">
										<div class="checkbox">
											<label>
												<input type="checkbox" class="styled" checked="checked">
												Remember me
											</label>
										</div>
									</div><?php */?>

									<div class="text-right">
										<input type="submit" id="doLogin" value="Login" class="btn no-border-radius" style="background-color:#1e3b71; color:#fff;">
									</div>
								</div>
							</div>
                           
							<div class="form-group text-center">
								 <?php /* ?><a href="<?php echo base_url(); ?>logins/forgotpassword">Forgot password?</a><?php */ ?>
							</div>
							
						</div>
                        <?php /* ?>
						<div class="panel-footer text-center">
							<a href="<?php echo base_url(); ?>logins/newusers">Create an account</a>
						</div>
						<?php */ ?>
					</div>
				</div>
				
			</form>
			<!-- /simple login form -->


			<!-- Footer -->
			<?php $this->load->view("logins/panels/footer"); ?>
			<!-- /footer -->

		</div>
		<!-- /page content -->

	</div>

</body>

</html>