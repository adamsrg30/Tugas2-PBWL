<!DOCTYPE html>
<html lang="en">

<head>
      <meta charset="UTF-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title><?php echo $site_name; ?> - Categories</title>

      <link type="text/css" rel="stylesheet" href="<?php echo $assets_path_css; ?>style.css">
	  <link type="text/css" rel="stylesheet" href="<?php echo $assets_path_fonts;?>fonts.css">
	  <link type="text/css" rel="stylesheet" href="<?php echo $assets_path_icons;?>icomoon/icomoon.css">
</head>

<body>

<?php $this->load->view('panels/aside'); ?>

      <main>
          <article>
<h2>CATEGORIES</h2>

<button id="tableAdd_button" type="button" class="btn" onclick="document.location.href='<?php echo base_url()."kategori/add"; ?>';"><i class="icon-plus3"></i> Add New Category</button>
<?php
if(!empty($mainlist)) {		  
?>
<table>
    <tr>
        <th>NO</th>
        <th>CATEGORY CODE</th>
        <th>NAME</th>
        <th>ACTION</th>
    </tr>
    <?php
	$no = 1;
	foreach ($mainlist as $ml) {
	?>
    <tr>
        <td><?php echo $no; ?></td>
        <td><?php echo $ml['gol_kode']; ?></td>
        <td><?php echo ucfirst($ml['gol_nama']); ?></td>
        <td>
			<button id="tableAdd_button" type="button" class="btn m-r-10" onclick="document.location.href='<?php echo base_url()."kategori/edit/".$ml['gol_id']; ?>';"> Edit</button>&nbsp;
			<button id="tableAdd_button" type="button" class="btn m-r-10" onclick="document.location.href='<?php echo base_url()."kategori/delete/".$ml['gol_id']; ?>';"<?php echo (($ml['countChild'] != 0) ? " disabled style=\"background-color:#f3f3f3; border-color:#f3f3f3; color:#000;\"" : ""); ?>> Delete</button>
		</td>
	</tr>
    <?php 
		$no++;	
	}
	?>
</table>
<?php
}
?>


		  </article>

<?php $this->load->view('panels/footer'); ?>
      </main>

</body>

</html>