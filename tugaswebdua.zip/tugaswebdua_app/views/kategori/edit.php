<!DOCTYPE html>
<html lang="en">

<head>
      <meta charset="UTF-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title><?php echo $site_name; ?> - Categories</title>

      <link type="text/css" rel="stylesheet" href="<?php echo $assets_path_css; ?>style.css">
	  <link type="text/css" rel="stylesheet" href="<?php echo $assets_path_fonts;?>fonts.css">
	  <link type="text/css" rel="stylesheet" href="<?php echo $assets_path_icons;?>icomoon/icomoon.css">
</head>

<body>

<?php $this->load->view('panels/aside'); ?>

      <main>
          <article>
<h2>EDIT CATEGORY</h2>

<form action="<?php echo base_url()."kategori/edit/".$details['gol_id']; ?>" method="post">
	<input type="hidden" name="action" value="edit" />
    <table>
        <tr>
            <td>Code</td>
            <td><input type="text" name="gol_kode" value="<?php echo $details['gol_kode']; ?>" required></td>
        </tr>
        <tr>
            <td>Name</td>
            <td><input type="text" name="gol_nama" value="<?php echo $details['gol_nama']; ?>" required></td>
        </tr>
        <tr>
            <td></td>
            <td>
				<input type="submit" name="btn_simpan" class="btn" value="SAVE">
				<input type="button" name="btn_balik" class="btn" onClick="javascript:document.location.href='<?php echo base_url()."kategori/"; ?>'" value="CANCEL">
			</td>
        </tr>
    </table>
</form>
		  </article>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<?php $this->load->view('panels/footer'); ?>
      </main>

</body>

</html>