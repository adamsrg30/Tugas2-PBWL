<!DOCTYPE html>
<html lang="en">

<head>
      <meta charset="UTF-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title><?php echo $site_name; ?> - Subscribers</title>

      <link type="text/css" rel="stylesheet" href="<?php echo $assets_path_css; ?>style.css">
	  <link type="text/css" rel="stylesheet" href="<?php echo $assets_path_fonts;?>fonts.css">
	  <link type="text/css" rel="stylesheet" href="<?php echo $assets_path_icons;?>icomoon/icomoon.css">
</head>

<body>

<?php $this->load->view('panels/aside'); ?>

      <main>
          <article>
<h2>SUBSCRIBERS</h2>

<button id="tableAdd_button" type="button" class="btn" onclick="document.location.href='<?php echo base_url()."pelanggan/add"; ?>';"><i class="icon-plus3"></i> Add New Subcriber</button>
<?php
if(!empty($mainlist)) {		  
?>
<table>
    <tr>
        <th>NO</th>
        <th>NAME</th>
        <th>SUBSCIBER NO</th>
        <th>CATEGORY</th>
        <th>USER</th>
        <th>ACTIVE</th>
        <th>ACTION</th>
    </tr>
    <?php
	$no = 1;
	foreach ($mainlist as $ml) {
		if($ml['pel_aktif'] == "Y") {
			$txtActive = "YES";
		} else {
			$txtActive = "NO";
		}
	?>
    <tr>
        <td><?php echo $no; ?></td>
        <td><?php echo ucfirst($ml['pel_nama']); ?></td>
        <td><?php echo $ml['pel_no']; ?></td>
        <td><?php echo ucfirst($ml['gol_nama']); ?></td>
        <td><?php echo ucfirst($ml['user_name']); ?></td>
        <td><?php echo $txtActive; ?></td>
        <td>
			<button id="tableAdd_button" type="button" class="btn m-r-10" onclick="document.location.href='<?php echo base_url()."pelanggan/edit/".$ml['pel_id']; ?>';"> Edit</button>&nbsp;
			<button id="tableAdd_button" type="button" class="btn m-r-10" onclick="document.location.href='<?php echo base_url()."pelanggan/delete/".$ml['pel_id']; ?>';"> Delete</button>
		</td>
	</tr>
    <?php 
		$no++;	
	}
	?>
</table>
<?php
}
?>

		  </article>

<?php $this->load->view('panels/footer'); ?>
      </main>

</body>

</html>