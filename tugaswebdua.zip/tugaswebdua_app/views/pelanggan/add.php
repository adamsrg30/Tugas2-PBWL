<!DOCTYPE html>
<html lang="en">

<head>
      <meta charset="UTF-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title><?php echo $site_name; ?> - Subscribers</title>

      <link type="text/css" rel="stylesheet" href="<?php echo $assets_path_css; ?>style.css">
	  <link type="text/css" rel="stylesheet" href="<?php echo $assets_path_fonts;?>fonts.css">
	  <link type="text/css" rel="stylesheet" href="<?php echo $assets_path_icons;?>icomoon/icomoon.css">
</head>

<body>

<?php $this->load->view('panels/aside'); ?>

      <main>
          <article>
<h2>ADD NEW SUBSCRIBERS</h2>

<form action="<?php echo base_url()."pelanggan/add"; ?>" method="post">
	<input type="hidden" name="action" value="add" />
    <table>
        <tr>
            <td>Name</td>
            <td><input type="text" name="pel_nama" required></td>
        </tr>
        <tr>
            <td>Category</td>
            <td>
				<?php
				if(!empty($kategori)) {
				?>
				<select name="pel_id_gol" required>
				<?php
					foreach($kategori as $k) {
				?>
					<option value="<?php echo $k['gol_id']; ?>"><?php echo $k['gol_nama']; ?></option>
				<?php
					}
				?>
				</select>
				<?php
				} else {
				?>
				<a href="<?php echo base_url()."kategori"; ?>" style="color:#AB0000;">Please Add Category First</a>
				<?php
				}
				?>
			</td>
        </tr>
        <tr>
            <td>Subscriber No</td>
            <td><input type="text" name="pel_no" required></td>
        </tr>
        <tr>
            <td>Address</td>
            <td><textarea name="pel_alamat" id="" cols="58" rows="10" required></textarea></td>
        </tr>
        <tr>
            <td>Handphone</td>
            <td><input type="text" name="pel_hp"></td>
        </tr>
        <tr>
            <td>KTP</td>
            <td><input type="text" name="pel_ktp" required></td>
        </tr>
        <tr>
            <td>Serial</td>
            <td><input type="text" name="pel_seri" required></td>
        </tr>
        <tr>
            <td>Metered</td>
            <td><input type="number" name="pel_meteran" required max="2147483647">&nbsp;<span class="text-size-mini" style="color:#AB0000">input number only</span></td>
        </tr>
        <tr>
            <td>Active</td>
            <td>
				<select name="pel_aktif">
					<option value="Y">YES</option>
					<option value="N">NO</option>
				</select>
			</td>
        </tr>
		<?php
		if($SessionLogin['user_role'] != "1") {
		?>
		<input type="hidden" name="pel_id_user" value="<?php echo $SessionLogin['user_id']; ?>" >		
		<?php
		} else {
 		?>
        <tr>
            <td>User</td>
            <td>
				<?php
				if(!empty($pengguna)) {
				?>
				<select name="pel_id_user" required>
				<?php
					foreach($pengguna as $p) {
				?>
					<option value="<?php echo $p['user_id']; ?>"><?php echo $p['user_name']; ?></option>
				<?php
					}
				?>
					
				</select>
				<?php
				} else {
				?>
				<a href="<?php echo base_url()."pengguna"; ?>" style="color:#AB0000;">Please Add User First</a>
				<?php
				}
				?>
			</td>
        </tr>
		<?php
		}
		?>
        <tr>
            <td></td>
            <td>
				<input type="submit" name="btn_simpan" class="btn" value="SAVE">
				<input type="button" name="btn_balik" class="btn" onClick="javascript:document.location.href='<?php echo base_url()."pelanggan/"; ?>'" value="CANCEL">
			</td>
        </tr>
    </table>
</form>
		  </article>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<?php $this->load->view('panels/footer'); ?>
      </main>

</body>

</html>