      <aside>

            <header>
                  <div class="user" style="color: #6B8BD8;"><?php echo $system_name; ?></div>
            </header>

 <div class="user-profile-container">
	<div class="user-profile clearfix">
		<div class="admin-user-thumb">
			<img src="<?php echo $assets_path_img; ?>default-dp.jpg" alt="<?php echo $SessionLogin['user_name']; ?>" class="img-circle">
		</div>
		<div class="admin-user-info">
			<ul class="user-info">
				<li><a href="index.php#" style="color: #6B8BD8; font-weight: bold;"><?php echo $SessionLogin['user_name']; ?></a></li>
				<li><a href="index.php#" style="color: #6B8BD8;" class="text-size-mini"><?php echo $SessionLogin['txtRole']; ?></a></li>
			</ul>
			<div class="logout-icon text-right"><a href="<?php echo base_url()."logins/logout"; ?>" style="color: #6B8BD8;"><i class="icon-exit2"></i></a></div>
		</div>
	</div>				
</div>

		  <nav>
				<ul>
                        <li>
                              <a href="<?php echo base_url(); ?>">
                                    <img class="icon" src="<?php echo $assets_path_img; ?>hunian.png" alt=""> Dashboard
                              </a>
                        </li>
						<?php
						if($SessionLogin['user_role'] == "1") {
						?>
                        <li>
                              <a href="<?php echo base_url()."pengguna/"; ?>">
                                    <img class="icon" src="<?php echo $assets_path_img; ?>warga.png" alt=""> Users
                              </a>
                        </li>
						<?php
						}
						?>
                        <li>
                              <a href="<?php echo base_url()."kategori/"; ?>">
                                    <img class="icon" src="<?php echo $assets_path_img; ?>iuran.png" alt=""> Categories
                              </a>
                        </li>
                        <li>
                              <a href="<?php echo base_url()."pelanggan/"; ?>">
                                    <img class="icon" src="<?php echo $assets_path_img; ?>payment.png" alt=""> Subscriptions
                              </a>
                        </li>
                  </ul>
            </nav>

      </aside>
